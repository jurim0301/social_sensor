//
//  evaluation.hpp
//  social_sensor
//
//  Created by Jurim Lee on 2018. 4. 30..
//  Copyright © 2018년 Jurim Lee. All rights reserved.
//

#ifndef evaluation_hpp
#define evaluation_hpp

#include <stdio.h>

#endif /* evaluation_hpp */
